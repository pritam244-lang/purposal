// script.js
document.getElementById("proposalBtn").addEventListener("click", function() {
    const message = document.getElementById("message");
    message.classList.remove("hidden");
    message.style.opacity = 1;

    // Create heart animation
    createHearts();
});

function createHearts() {
    for (let i = 0; i < 20; i++) {
        const heart = document.createElement("div");
        heart.classList.add("heart");
        heart.textContent = "❤️";
        heart.style.left = Math.random() * 100 + "vw";
        heart.style.animationDelay = Math.random() * 2 + "s";
        document.body.appendChild(heart);

        // Remove heart after animation
        setTimeout(() => {
            heart.remove();
        }, 2000);
    }
}
